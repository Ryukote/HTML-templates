// Elite Performance Tuning - Main JavaScript

// ==================== CONFIGURATION ====================
let contentData = {};
let imagesData = {};
let diagonalImages = [];
let currentDiagonalIndex = 0;

// ==================== THEME TOGGLE ====================
const themeToggleBtn = document.getElementById('theme-toggle');
const htmlElement = document.documentElement;
const themeToggleDarkIcon = document.getElementById('theme-toggle-dark-icon');
const themeToggleLightIcon = document.getElementById('theme-toggle-light-icon');

// Check for saved theme preference or default to light mode
const currentTheme = localStorage.getItem('theme') || 'light';

// Set initial theme
if (currentTheme === 'dark') {
    htmlElement.classList.add('dark');
    themeToggleLightIcon.classList.remove('hidden');
} else {
    htmlElement.classList.remove('dark');
    themeToggleDarkIcon.classList.remove('hidden');
}

// Toggle theme
themeToggleBtn.addEventListener('click', function() {
    htmlElement.classList.toggle('dark');

    if (htmlElement.classList.contains('dark')) {
        localStorage.setItem('theme', 'dark');
        themeToggleLightIcon.classList.remove('hidden');
        themeToggleDarkIcon.classList.add('hidden');
    } else {
        localStorage.setItem('theme', 'light');
        themeToggleDarkIcon.classList.remove('hidden');
        themeToggleLightIcon.classList.add('hidden');
    }
});

// ==================== MOBILE MENU ====================
const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
const mobileMenu = document.getElementById('mobile-menu');

mobileMenuToggle.addEventListener('click', () => {
    mobileMenu.classList.toggle('hidden');
});

// Close mobile menu when clicking on a link
const mobileMenuLinks = mobileMenu.querySelectorAll('a');
mobileMenuLinks.forEach(link => {
    link.addEventListener('click', () => {
        mobileMenu.classList.add('hidden');
    });
});

// ==================== LOAD IMAGES FROM JSON ====================
async function loadImages() {
    try {
        console.log('Loading images.json...');
        const response = await fetch('images.json');

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        imagesData = await response.json();
        console.log('Images data loaded:', imagesData);

        diagonalImages = imagesData.hero.diagonal;

        // Initialize diagonal split images
        if (diagonalImages && diagonalImages.length > 0) {
            console.log(`Initializing ${diagonalImages.length} diagonal image pairs`);
            initDiagonalSplit();
        }

        // Load gallery images dynamically
        if (imagesData.gallery) {
            console.log(`Found ${imagesData.gallery.length} gallery images`);
            populateGallery(imagesData.gallery);
        } else {
            console.error('No gallery images found in images.json');
        }

        // Update testimonial avatars
        if (imagesData.testimonials) {
            console.log(`Updating ${imagesData.testimonials.length} testimonial avatars`);
            updateTestimonialAvatars(imagesData.testimonials);
        }
    } catch (error) {
        console.error('Error loading images:', error);
    }
}

// ==================== DIAGONAL SPLIT IMAGE ROTATION ====================
function initDiagonalSplit() {
    // Start rotation after initial load
    setTimeout(() => {
        startDiagonalRotation();
    }, 5000); // Wait 5 seconds before first transition
}

function startDiagonalRotation() {
    setInterval(() => {
        rotateDiagonalImages();
    }, 6000); // Change images every 6 seconds
}

function rotateDiagonalImages() {
    const leftImg = document.getElementById('diagonal-left-img');
    const rightImg = document.getElementById('diagonal-right-img');

    if (!leftImg || !rightImg || !diagonalImages || diagonalImages.length === 0) return;

    // Fade out current images
    leftImg.classList.add('fade-out');
    rightImg.classList.add('fade-out');

    // After fade out, change images
    setTimeout(() => {
        currentDiagonalIndex = (currentDiagonalIndex + 1) % diagonalImages.length;
        const newImages = diagonalImages[currentDiagonalIndex];

        leftImg.src = newImages.left;
        rightImg.src = newImages.right;
        leftImg.alt = newImages.alt + ' Left';
        rightImg.alt = newImages.alt + ' Right';

        // Fade in new images
        leftImg.classList.remove('fade-out');
        rightImg.classList.remove('fade-out');
        leftImg.classList.add('fade-in');
        rightImg.classList.add('fade-in');

        // Remove fade-in class after transition
        setTimeout(() => {
            leftImg.classList.remove('fade-in');
            rightImg.classList.remove('fade-in');
        }, 1500);
    }, 1500); // Wait for fade out to complete
}

// ==================== LOAD CONTENT FROM JSON ====================
async function loadContent() {
    try {
        const response = await fetch('content.json');
        contentData = await response.json();
        populateContent();
    } catch (error) {
        console.error('Error loading content:', error);
        // Use default content if JSON fails to load
        loadDefaultContent();
    }
}

function populateContent() {
    // Page Title
    if (contentData.site) {
        document.getElementById('page-title').textContent = contentData.site.title;
        document.getElementById('brand-name').textContent = contentData.site.brandName;
        document.getElementById('logo-text').textContent = contentData.site.logoText;
    }

    // Navigation
    if (contentData.navigation) {
        const navLinks = document.querySelectorAll('.nav-link');
        contentData.navigation.forEach((item, index) => {
            if (navLinks[index]) {
                navLinks[index].textContent = item.text;
            }
        });
    }

    // Hero Section
    if (contentData.hero) {
        document.getElementById('hero-title').textContent = contentData.hero.title;
        document.getElementById('hero-subtitle').textContent = contentData.hero.subtitle;
        document.getElementById('hero-cta-primary').textContent = contentData.hero.ctaPrimary;
        document.getElementById('hero-cta-secondary').textContent = contentData.hero.ctaSecondary;
    }

    // Services Section
    if (contentData.services) {
        document.getElementById('services-title').textContent = contentData.services.title;
        document.getElementById('services-subtitle').textContent = contentData.services.subtitle;
        populateServices(contentData.services.items);
    }

    // Stats Section
    if (contentData.stats) {
        populateStats(contentData.stats);
    }

    // Gallery Section
    if (contentData.gallery) {
        document.getElementById('gallery-title').textContent = contentData.gallery.title;
        document.getElementById('gallery-subtitle').textContent = contentData.gallery.subtitle;
        // Gallery images loaded from images.json in loadImages()
    }

    // Testimonials Section
    if (contentData.testimonials) {
        document.getElementById('testimonials-title').textContent = contentData.testimonials.title;
        document.getElementById('testimonials-subtitle').textContent = contentData.testimonials.subtitle;
        populateTestimonials(contentData.testimonials.items);
    }

    // Contact Section
    if (contentData.contact) {
        document.getElementById('contact-title').textContent = contentData.contact.title;
        document.getElementById('contact-subtitle').textContent = contentData.contact.subtitle;
        document.getElementById('form-label-name').textContent = contentData.contact.form.labelName;
        document.getElementById('form-label-email').textContent = contentData.contact.form.labelEmail;
        document.getElementById('form-label-phone').textContent = contentData.contact.form.labelPhone;
        document.getElementById('form-label-message').textContent = contentData.contact.form.labelMessage;
        document.getElementById('form-submit-btn').textContent = contentData.contact.form.submitButton;

        document.getElementById('contact-info-title-location').textContent = contentData.contact.info.locationTitle;
        document.getElementById('contact-info-address').textContent = contentData.contact.info.address;
        document.getElementById('contact-info-title-phone').textContent = contentData.contact.info.phoneTitle;
        document.getElementById('contact-info-phone').textContent = contentData.contact.info.phone;
        document.getElementById('contact-info-title-email').textContent = contentData.contact.info.emailTitle;
        document.getElementById('contact-info-email').textContent = contentData.contact.info.email;
        document.getElementById('contact-info-title-hours').innerHTML = contentData.contact.info.hoursTitle;
        document.getElementById('contact-info-hours').innerHTML = contentData.contact.info.hours;
    }

    // Footer
    if (contentData.footer) {
        document.getElementById('footer-about-title').textContent = contentData.footer.aboutTitle;
        document.getElementById('footer-about-text').textContent = contentData.footer.aboutText;
        document.getElementById('footer-services-title').textContent = contentData.footer.servicesTitle;
        document.getElementById('footer-links-title').textContent = contentData.footer.linksTitle;
        document.getElementById('footer-social-title').textContent = contentData.footer.socialTitle;
        document.getElementById('footer-copyright').textContent = contentData.footer.copyright;
    }
}

function populateServices(services) {
    const servicesGrid = document.getElementById('services-grid');
    servicesGrid.innerHTML = '';

    services.forEach((service, index) => {
        const serviceCard = document.createElement('div');
        serviceCard.className = 'service-card p-8 rounded-2xl shadow-lg tilt-card';
        serviceCard.setAttribute('data-aos', 'fade-up');
        serviceCard.setAttribute('data-aos-delay', index * 100);

        serviceCard.innerHTML = `
            <div class="service-icon text-5xl mb-6">${service.icon}</div>
            <h3 class="text-2xl font-bold mb-4">${service.title}</h3>
            <p class="text-gray-600 dark:text-gray-400 mb-6">${service.description}</p>
            <ul class="space-y-2 text-gray-600 dark:text-gray-400">
                ${service.features.map(feature => `
                    <li class="flex items-center">
                        <svg class="w-5 h-5 text-primary mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                        </svg>
                        ${feature}
                    </li>
                `).join('')}
            </ul>
        `;

        servicesGrid.appendChild(serviceCard);
    });

    // Reinitialize tilt for new cards
    initTilt();
}

function populateStats(stats) {
    const statsGrid = document.getElementById('stats-grid');
    statsGrid.innerHTML = '';

    stats.forEach((stat, index) => {
        const statCard = document.createElement('div');
        statCard.className = 'text-center';
        statCard.setAttribute('data-aos', 'zoom-in');
        statCard.setAttribute('data-aos-delay', index * 100);

        statCard.innerHTML = `
            <div class="stat-number" data-target="${stat.number}">${stat.number}</div>
            <p class="text-xl mt-2 opacity-90">${stat.label}</p>
        `;

        statsGrid.appendChild(statCard);
    });

    // Animate counters
    animateCounters();
}

function populateGallery(images) {
    const gallerySlides = document.getElementById('gallery-slides');

    if (!gallerySlides) {
        console.error('Gallery slides container not found!');
        return;
    }

    if (!images || images.length === 0) {
        console.error('No gallery images provided!');
        return;
    }

    console.log(`Loading ${images.length} gallery images...`);

    gallerySlides.innerHTML = '';

    images.forEach((image, index) => {
        const slide = document.createElement('li');
        slide.className = 'splide__slide';

        slide.innerHTML = `
            <div class="relative group">
                <img src="${image.url}" alt="${image.alt}" class="w-full h-96 object-cover rounded-2xl gallery-image" loading="lazy">
                <div class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-2xl flex items-end">
                    <div class="p-6 text-white">
                        <p class="text-sm font-semibold uppercase tracking-wider text-primary">${image.category || ''}</p>
                        <p class="text-lg">${image.alt}</p>
                    </div>
                </div>
            </div>
        `;

        gallerySlides.appendChild(slide);
        console.log(`Added gallery image ${index + 1}: ${image.url}`);
    });

    // Initialize Splide after a short delay to ensure DOM is ready
    setTimeout(() => {
        initSplide();
    }, 100);
}

function updateTestimonialAvatars(avatars) {
    const testimonialCards = document.querySelectorAll('.testimonial-card img');

    avatars.forEach((avatar, index) => {
        if (testimonialCards[index]) {
            testimonialCards[index].src = avatar.avatar;
            testimonialCards[index].alt = avatar.name;
        }
    });
}

function populateTestimonials(testimonials) {
    const testimonialsGrid = document.getElementById('testimonials-grid');
    testimonialsGrid.innerHTML = '';

    testimonials.forEach((testimonial, index) => {
        const testimonialCard = document.createElement('div');
        testimonialCard.className = 'testimonial-card p-8 rounded-2xl shadow-lg tilt-card';
        testimonialCard.setAttribute('data-aos', 'fade-up');
        testimonialCard.setAttribute('data-aos-delay', index * 100);

        testimonialCard.innerHTML = `
            <div class="flex items-center mb-4">
                <img src="${testimonial.avatar}" alt="${testimonial.name}" class="w-16 h-16 rounded-full mr-4 object-cover">
                <div>
                    <h4 class="font-bold text-lg">${testimonial.name}</h4>
                    <p class="text-gray-600 dark:text-gray-400">${testimonial.car}</p>
                </div>
            </div>
            <div class="flex mb-4">
                ${Array(testimonial.rating).fill('⭐').join('')}
            </div>
            <p class="text-gray-600 dark:text-gray-400 italic">"${testimonial.text}"</p>
        `;

        testimonialsGrid.appendChild(testimonialCard);
    });

    // Reinitialize tilt for new cards
    initTilt();
}

// ==================== COUNTER ANIMATION ====================
function animateCounters() {
    const counters = document.querySelectorAll('.stat-number');

    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'));
        const duration = 2000; // 2 seconds
        const increment = target / (duration / 16); // 60fps
        let current = 0;

        const updateCounter = () => {
            current += increment;
            if (current < target) {
                counter.textContent = Math.floor(current) + '+';
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target + '+';
            }
        };

        // Start animation when element is in viewport
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    updateCounter();
                    observer.unobserve(entry.target);
                }
            });
        });

        observer.observe(counter);
    });
}

// ==================== VANILLA TILT INITIALIZATION ====================
function initTilt() {
    const tiltElements = document.querySelectorAll('.tilt-card');

    VanillaTilt.init(tiltElements, {
        max: 15,
        speed: 400,
        glare: true,
        'max-glare': 0.3,
        scale: 1.05,
        perspective: 1000,
        transition: true
    });
}

// ==================== SPLIDE CAROUSEL INITIALIZATION ====================
let splideInstance = null;

function initSplide() {
    const splideElement = document.querySelector('.splide');

    if (!splideElement) {
        console.warn('Splide element not found');
        return;
    }

    // Destroy existing instance if it exists
    if (splideInstance) {
        try {
            splideInstance.destroy();
        } catch (e) {
            console.log('No previous Splide instance to destroy');
        }
    }

    // Create new instance
    try {
        splideInstance = new Splide('.splide', {
            type: 'loop',
            perPage: 3,
            perMove: 1,
            gap: '2rem',
            autoplay: true,
            interval: 3000,
            pauseOnHover: true,
            breakpoints: {
                1024: {
                    perPage: 2,
                },
                768: {
                    perPage: 1,
                }
            }
        });

        splideInstance.mount();
        console.log('Splide initialized successfully');
    } catch (error) {
        console.error('Error initializing Splide:', error);
    }
}

// ==================== AOS INITIALIZATION ====================
function initAOS() {
    if (typeof AOS !== 'undefined') {
        AOS.init({
            duration: 1000,
            easing: 'ease-out-cubic',
            once: true,
            offset: 100,
            delay: 0
        });
        console.log('AOS initialized successfully');
    } else {
        console.error('AOS library not loaded');
    }
}

// ==================== LENIS SMOOTH SCROLL INITIALIZATION ====================
function initLenis() {
    const lenis = new Lenis({
        duration: 1.2,
        easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        orientation: 'vertical',
        gestureOrientation: 'vertical',
        smoothWheel: true,
        wheelMultiplier: 1,
        smoothTouch: false,
        touchMultiplier: 2,
        infinite: false,
    });

    function raf(time) {
        lenis.raf(time);
        requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);

    // Smooth scroll to anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                lenis.scrollTo(target, {
                    offset: -80,
                    duration: 1.5
                });
            }
        });
    });
}

// ==================== CONTACT FORM HANDLING ====================
const contactForm = document.getElementById('contact-form');
contactForm.addEventListener('submit', function(e) {
    e.preventDefault();

    // Get form values
    const name = document.getElementById('form-input-name').value;
    const email = document.getElementById('form-input-email').value;
    const phone = document.getElementById('form-input-phone').value;
    const message = document.getElementById('form-input-message').value;

    // Here you would typically send the form data to a server
    console.log('Form submitted:', { name, email, phone, message });

    // Show success message
    alert('Thank you for your message! We will get back to you soon.');

    // Reset form
    contactForm.reset();
});

// ==================== NAVIGATION SCROLL EFFECT ====================
let lastScroll = 0;
const nav = document.querySelector('nav');

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;

    if (currentScroll > 100) {
        nav.classList.add('nav-scrolled');
    } else {
        nav.classList.remove('nav-scrolled');
    }

    lastScroll = currentScroll;
});

// ==================== DEFAULT CONTENT (FALLBACK) ====================
function loadDefaultContent() {
    console.log('Using default content');
    // Content is already in HTML, so no action needed
}

// ==================== INITIALIZE EVERYTHING ====================
document.addEventListener('DOMContentLoaded', async function() {
    // Load content and images from JSON
    await Promise.all([
        loadContent(),
        loadImages()
    ]);

    // Initialize all libraries
    initTilt();
    initAOS();
    initLenis();

    // Add smooth reveal animation
    setTimeout(() => {
        document.body.style.opacity = '1';
    }, 100);
});

// ==================== PERFORMANCE OPTIMIZATIONS ====================
// Lazy load images
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                if (img.dataset.src) {
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                    observer.unobserve(img);
                }
            }
        });
    });

    document.querySelectorAll('img[data-src]').forEach(img => {
        imageObserver.observe(img);
    });
}

// Preload critical resources
window.addEventListener('load', () => {
    // Refresh AOS calculations after all content is loaded
    AOS.refresh();
});
