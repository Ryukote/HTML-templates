# Image sources

## Notice

I am not the owner of any photo in this template. All photos are reused on various websites and I have reused them myself. Whoever buy this template is expected to provide their own photos.

## Car images

car-1-left taken from "https://velikagorica.com/vijesti/cityportal-140928"
car-1-right taken from "https://f1-ferrari-shop.com/upgrading-your-mercedes-with-custom-amg-rims/"

car-2-left taken from "https://www.pexels.com/photo/photo-of-black-lamborghini-3802508/"
car-2-right taken from "https://autodetailz.co.uk/blog/the-window-tinting-process-what-to-expect-autodetailz-window-tinting-brentwood/"

car-3-left taken from "https://www.processexcellencenetwork.com/digital-transformation/news/toyota-accelerates-digital-transformation-with-sap-s4hana-upgrades"
car-3-right taken from "https://www.pexels.com/photo/photo-of-black-lamborghini-3802510/"

car-4-left taken from "https://autodana.eu/blog/zasto-se-cuje-klopotanje-iz-donjeg-dijela-auta/"
car-4-right taken from "https://vareko-promet.hr/mauris-a-nunc-occideritis-3/"

## People images

client-1 taken from "https://ephesianchristianassembly.org/people/karls-marrianes/
client-2 taken from "https://grownandflown.com/author/irenasmith/"
client-3 taken from "https://fullofprunes.com/home/"
client-4 taken from "https://themesmaestro.com/perprog/styletwo/category/lifestyle/"
client-5 taken from "https://www.collabh.com/about/"
client-6 taken from "https://galekovic-dental.eu/blog/ciscenje-jezika-za-dobar-zadah-17/"